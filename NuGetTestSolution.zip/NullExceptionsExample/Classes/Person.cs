﻿namespace NullExceptionsExample.Classes
{
    public class Person
    {
        public string Name { get; set; }
    }
}
